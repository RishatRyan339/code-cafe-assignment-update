<?php

    
 function signup( $user_name, $email, $phone, $dob, $password ){
     $conn = getConnection();
     $isok = false;
     $sql = "INSERT INTO members (user_name, email, phone, dob, password) VALUES ('$user_name', '$email', '$phone', '$dob', '$password')";
     if ($conn->query($sql) === TRUE) {
         session_start();
         $_SESSION['error'] = "New record created successfully";
         session_unset();
         $isok = true;
     } else {
         session_start();
         $_SESSION['error'] = "Something went wrong try again!";
         session_unset();
     }
     $conn->close();
     return $isok;
 }


 function login( $email, $password ){
    $conn = getConnection();
    $isok = false;
    $sql = "SELECT * FROM members WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        session_start();
        $_SESSION['error'] = "Login successful";
        session_unset();
        $isok = true;
    } else {
        session_start();
        $_SESSION['error'] = "Invalid email or password";
        session_unset();
    }
    $conn->close();
    return $isok;
}
