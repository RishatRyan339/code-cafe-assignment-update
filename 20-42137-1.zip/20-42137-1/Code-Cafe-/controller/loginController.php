
<?php 
    
    session_start();
  
    include '../Model/db.php';
    include '../Model/alldb.php';

    $conn = getConnection();
    if ( $_SERVER['REQUEST_METHOD'] == 'POST' ){


        if ( isset($_POST['buttonlogin']) ){
            $email = $_POST['email'];
            $password = $_POST['password'];

            if ( empty($_POST['email']) ){
                $_SESSION['error'] = "Email is required.";
            } elseif ( empty($_POST['password']) ){
                $_SESSION['error'] = "Password is required.";
            } else {
                if ( login($email, $password) ){
                   
                    $sql = "SELECT * FROM members WHERE email='$email' AND password='$password'";
                    $result = $conn->query($sql);
                    $row = $result->fetch_assoc();
                    $_SESSION['email'] = $row['email'];
                    header('Location: ../View/landing.php');
                } else {
                    header('Location: ../View/login.php');
                }
            }
        }

    }

        

?>